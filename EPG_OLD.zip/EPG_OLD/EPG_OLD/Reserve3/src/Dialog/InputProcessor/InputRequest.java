/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dialog.InputProcessor;

public interface InputRequest {

    /**
     * 
     * @author dosdiaopfhj
     * @return 入力待ちの際に表示するメッセージ。
     */
    String inputRequestMessages();
}
