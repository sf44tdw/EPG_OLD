/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Common;

import LoggerConfigurator.LoggerConfigurator;
import java.io.File;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author normal
 */
public class Const {

    private static final Logger logger = LoggerConfigurator.getCallerLogger();

    public static void setLevelALL() {

        // Logger の Level 設定
        System.out.print("Logger's LogLevel is changed from " + logger.getLevel());
        logger.setLevel(Level.ALL);
        System.out.println(" to " + logger.getLevel());

//        logger.addHandler(new ConsoleHandler());
        // Handler の Level 設定
        Handler[] handlers = logger.getHandlers();
        for (Handler handler : handlers) {
            System.out.println(handler + "'s Level: " + handler.getLevel());
            System.out.print("Handler's LogLevel is changed from " + handler.getLevel());
            handler.setLevel(Level.ALL);
            System.out.println(" to " + handler.getLevel());

        }
    }
    public static final Charset CHARCODE = StandardCharsets.UTF_8;

    private static final String TESTDATADIR_S = "I:/xml";

    /**
     * テストデータ置き場
     */
    public static final File TESTDATADIR = new File(TESTDATADIR_S);

    /**
     * XMLファイル1
     */
    public static final File TESTDATA_XML_1 = new File(TESTDATADIR, "26.xml");

    /**
     * XMLファイル2
     */
    public static final File TESTDATA_XML_2 = new File(TESTDATADIR, "23.xml");

    /**
     * DTDファイル名
     */
    public static final String DTD_FILE_NAME = "xmltv.dtd";

    /**
     * DTDファイル
     */
    public static final File DTDFILE = new File(TESTDATADIR, DTD_FILE_NAME);

    /**
     * 見られないチャンネルのリスト。
     */
    public static final Set<Integer> getDummyPaidBroadcastings() {
        Set<Integer> tempPaidBroadcastings = new HashSet<>();
        tempPaidBroadcastings.add(10);
        tempPaidBroadcastings.add(20);
        tempPaidBroadcastings.add(30);
        return Collections.unmodifiableSet(tempPaidBroadcastings);
    }
}
