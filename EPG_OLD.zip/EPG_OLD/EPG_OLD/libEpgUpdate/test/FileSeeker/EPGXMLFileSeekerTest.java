/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FileSeeker;

import ListMaker.FileSeeker.FileSeeker;
import java.io.File;
import java.util.List;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * @author dosdiaopfhj
 */
public class EPGXMLFileSeekerTest {
    private final IOFileFilter suffix1 = FileFilterUtils.suffixFileFilter("xml");
    private final IOFileFilter suffix2 = FileFilterUtils.suffixFileFilter("Xml");
    private final IOFileFilter suffix3 = FileFilterUtils.suffixFileFilter("xMl");
    private final IOFileFilter suffix4 = FileFilterUtils.suffixFileFilter("xmL");
    private final IOFileFilter suffix5 = FileFilterUtils.suffixFileFilter("XMl");
    private final IOFileFilter suffix6 = FileFilterUtils.suffixFileFilter("xML");
    private final IOFileFilter suffix7 = FileFilterUtils.suffixFileFilter("XmL");
    private final IOFileFilter suffix8 = FileFilterUtils.suffixFileFilter("XML");
    
    public EPGXMLFileSeekerTest() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of isRecursive method, of class FileSeeker.
     */
    @Test
    public void testIsRecursive() {
        System.out.println("isRecursive");
        FileSeeker instance = new FileSeeker(new File("J:/"),FileFilterUtils.or(suffix1, suffix2, suffix3, suffix4, suffix5, suffix6, suffix7, suffix8));
        boolean expResult = true;
        boolean result = instance.isRecursive();
        assertEquals(expResult, result);
    }

    /**
     * Test of setRecursive method, of class FileSeeker.
     */
    @Test
    public void testSetRecursive() {
        System.out.println("setRecursive");
        boolean recursive = false;
        FileSeeker instance = new FileSeeker(new File("J:/"),FileFilterUtils.or(suffix1, suffix2, suffix3, suffix4, suffix5, suffix6, suffix7, suffix8));
        boolean expResult = instance.isRecursive();
        instance.setRecursive(recursive);
        boolean result = instance.isRecursive();
        assertEquals(!expResult, result);
    }

    /**
     * Test of seek method, of class FileSeeker.
     */
    @Test
    public void testSeek() {
        System.out.println("seek");
        FileSeeker instance = new FileSeeker(new File("J:/"),FileFilterUtils.or(suffix1, suffix2, suffix3, suffix4, suffix5, suffix6, suffix7, suffix8));
        instance.setRecursive(false);
        List<File> result = instance.seek();
        assertNotNull(result);
    }

}
