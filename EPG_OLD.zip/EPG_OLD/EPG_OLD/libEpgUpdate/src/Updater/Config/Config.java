/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Updater.Config;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * Updaterの設定を保持するクラス。
 *
 * @author normal
 */
public final class Config {

    private final java.sql.Connection connection;

    private final File dTDPath;
    private final File xMLDirectory;
    private final Charset xMLFileCharCode;
    private final Set<Integer> paidBroadcastings;

    /**
     * Updaterの設定を受け取る。
     *
     * @param connection 更新対象のDBへの接続。
     * @param dTDPath DTDファイルへのパス。
     * @param xMLDirectory EPG XMLファイルの入っているディレクトリ。サブディレクトリのファイルは無視する。
     * @param xMLFileCharCode EPG XMLファイルの文字コード。
     * @param paidBroadcastings 視聴できないチャンネルのリスト(主に有料放送)。
     */
    public Config(java.sql.Connection connection, File dTDPath, File xMLDirectory, Charset xMLFileCharCode, Set<Integer> paidBroadcastings) throws NullPointerException, IllegalArgumentException {
        if (connection != null) {
            this.connection = connection;
        } else {
            throw new NullPointerException("DBへの接続がありません。");
        }
        if (dTDPath != null && dTDPath.isFile()) {
            this.dTDPath = new File(dTDPath.getAbsolutePath());
        } else {
            throw new IllegalArgumentException("DTDファイルへのパスが不正です。");
        }
        if (xMLDirectory != null && xMLDirectory.isDirectory()) {
            this.xMLDirectory = new File(xMLDirectory.getAbsolutePath());
        } else {
            throw new IllegalArgumentException("XMLファイルの入っているディレクトリへのパスが不正です。");
        }
        if (xMLFileCharCode != null) {
            this.xMLFileCharCode = xMLFileCharCode;
        } else {
            throw new NullPointerException("XMLファイルの読み込み用文字コードがありません。");
        }
        if (paidBroadcastings != null && paidBroadcastings.size() >= 0) {
            Set<Integer> tempPaidBroadcastings = new HashSet<>();
            tempPaidBroadcastings.addAll(paidBroadcastings);
            this.paidBroadcastings = Collections.unmodifiableSet(tempPaidBroadcastings);
        } else {
            throw new IllegalArgumentException("視聴できないチャンネルのリストがありません。");
        }
    }

    /**
     * @return DB接続。
     */
    public synchronized java.sql.Connection getConention() {
        return connection;
    }

    /**
     * @return DTDファイル。
     */
    public synchronized File getDTDPath() {
        return new File(dTDPath.getAbsolutePath());
    }

    /**
     * @return XMLファイルの入っているディレクトリ。
     */
    public synchronized File getXMLDirectory() {
        return new File(xMLDirectory.getAbsolutePath());
    }

    /**
     * @return XMLファイルの文字コード。
     */
    public synchronized Charset getXMLFileCharCode() {
        return xMLFileCharCode;
    }

    /**
     * @return 見られないチャンネルの一覧。
     */
    public synchronized Set<Integer> getPaidBroadcastings() {
        Set<Integer> tempPaidBroadcastings = new HashSet<>();
        tempPaidBroadcastings.addAll(paidBroadcastings);
        return Collections.unmodifiableSet(tempPaidBroadcastings);
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 43 * hash + Objects.hashCode(this.connection);
        hash = 43 * hash + Objects.hashCode(this.dTDPath);
        hash = 43 * hash + Objects.hashCode(this.xMLDirectory);
        hash = 43 * hash + Objects.hashCode(this.xMLFileCharCode);
        hash = 43 * hash + Objects.hashCode(this.paidBroadcastings);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Config other = (Config) obj;
        if (!Objects.equals(this.connection, other.connection)) {
            return false;
        }
        if (!Objects.equals(this.dTDPath, other.dTDPath)) {
            return false;
        }
        if (!Objects.equals(this.xMLDirectory, other.xMLDirectory)) {
            return false;
        }
        if (!Objects.equals(this.xMLFileCharCode, other.xMLFileCharCode)) {
            return false;
        }
        if (!Objects.equals(this.paidBroadcastings, other.paidBroadcastings)) {
            return false;
        }
        return true;
    }

    /**
     * テキストに変換可能なものを全てダンプする。
     *
     * @return このオブジェクトが保存している内容えお文字列に変換したもの。
     */
    @Override
    public synchronized String toString() {
        try {
            final BeanInfo info = Introspector.getBeanInfo(this.getClass(), Object.class);
            final PropertyDescriptor[] props = info.getPropertyDescriptors();
            final StringBuffer buf = new StringBuffer(500);
            Object value = null;
            buf.append(getClass().getName());
            buf.append("@");  //$NON-NLS-1$
            buf.append(hashCode());
            buf.append("={");  //$NON-NLS-1$
            for (int idx = 0; idx < props.length; idx++) {
                if (idx != 0) {
                    buf.append(", ");  //$NON-NLS-1$
                }
                buf.append(props[idx].getName());
                buf.append("=");  //$NON-NLS-1$
                if (props[idx].getReadMethod() != null) {
                    value = props[idx].getReadMethod()
                            .invoke(this, new Object[]{});
                    if (value instanceof Config) {
                        buf.append("@");  //$NON-NLS-1$
                        buf.append(value.hashCode());
                    } else if (value instanceof Collection) {
                        buf.append("{");  //$NON-NLS-1$
                        for (Object element : ((Collection<?>) value)) {
                            if (element instanceof Config) {
                                buf.append("@");  //$NON-NLS-1$
                                buf.append(element.hashCode());
                            } else {
                                buf.append(element.toString());
                            }
                        }
                        buf.append("}");  //$NON-NLS-1$
                    } else if (value instanceof Map) {
                        buf.append("{");  //$NON-NLS-1$
                        Map<?, ?> map = (Map) value;
                        for (Object key : map.keySet()) {
                            Object element = map.get(key);
                            buf.append(key.toString()).append("=");
                            if (element instanceof Config) {
                                buf.append("@");  //$NON-NLS-1$
                                buf.append(element.hashCode());
                            } else {
                                buf.append(element.toString());
                            }
                        }
                        buf.append("}");  //$NON-NLS-1$
                    } else {
                        if (value != null) {
                            buf.append(value);
                        } else {
                            buf.append("null");
                        }
                    }
                }
            }
            buf.append("}");  //$NON-NLS-1$
            return buf.toString();
        } catch (IntrospectionException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
            throw new RuntimeException(ex);
        }
    }
}
