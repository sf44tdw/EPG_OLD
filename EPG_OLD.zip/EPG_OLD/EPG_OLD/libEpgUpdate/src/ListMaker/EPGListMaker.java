/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ListMaker;

import ListMaker.FileSeeker.FileSeeker;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.w3c.dom.Document;
import LoggerConfigurator.LoggerConfigurator;
import java.nio.charset.Charset;

/**
 * 指定されたディレクトリかたxmlファイルを捜索する。サブディレクトリは無視する。
 * @author dosdiaopfhj
 */
public class EPGListMaker {

    private final FileSeeker seeker;

    private final IOFileFilter suffix1 = FileFilterUtils.suffixFileFilter("xml");
    private final IOFileFilter suffix2 = FileFilterUtils.suffixFileFilter("Xml");
    private final IOFileFilter suffix3 = FileFilterUtils.suffixFileFilter("xMl");
    private final IOFileFilter suffix4 = FileFilterUtils.suffixFileFilter("xmL");
    private final IOFileFilter suffix5 = FileFilterUtils.suffixFileFilter("XMl");
    private final IOFileFilter suffix6 = FileFilterUtils.suffixFileFilter("xML");
    private final IOFileFilter suffix7 = FileFilterUtils.suffixFileFilter("XmL");
    private final IOFileFilter suffix8 = FileFilterUtils.suffixFileFilter("XML");

    private final Charset charset;
    private final File DTD;

    private static final Logger log = LoggerConfigurator.getCallerLogger();

    /**
     * EPG XMLファイルを読み込む際、DTDファイルの場所を指定する。
     *
     * @param sourceDir ファイルを検索するディレクトリ
     * @param charset 読み込むファイルの文字コード。
     * @param DTD DTDファイル。読み込みに失敗した場合、XMLファイルに指定されたパスからDTDファイルを読み込もうとする。
     */
    public EPGListMaker(File sourceDir, Charset charset, File DTD) {
        this.charset = charset;
        seeker = new FileSeeker(sourceDir, FileFilterUtils.or(suffix1, suffix2, suffix3, suffix4, suffix5, suffix6, suffix7, suffix8));
        seeker.setRecursive(false);
        this.DTD = DTD;
    }

    /**
     * EPG XMLファイルの検索を行い、見つかったファイルを読み込む。
     *
     * @return 見つかったファイルを変換したDocumentオブジェクトのリスト。読み込みに失敗したファイルは無視する。
     */
    public synchronized List<Document> seek() {
        List<Document> EPGs = Collections.synchronizedList(new ArrayList<Document>());
        List<File> FL = this.seeker.seek();
        Iterator<File> it_F = FL.iterator();
        while (it_F.hasNext()) {
            File F = it_F.next();
            Document d = new XMLLoader(charset, this.DTD).Load(F);
            if (d != null) {
                log.log(Level.INFO, "EPGファイルが読み込まれました。 EPG FILE={0}", F.toString());
                EPGs.add(d);
            } else {
                log.log(Level.WARNING, "EPGファイルが読み込まれませんでした。このファイルは無視されます。 EPG FILE={0}", F.toString());
            }
        }
        return EPGs;
    }
}
