/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ListMaker;

import LoggerConfigurator.LoggerConfigurator;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * xmltv.dtdをファイルから読み込ませる。
 *
 * @author normal
 */
public class XmlTvDTDResolver implements EntityResolver {

    private static final Logger log = LoggerConfigurator.getCallerLogger();
    private static final String DTD_NAME = "xmltv.dtd";

    private static final String MSG_SUCCESS = "{0}は実在するファイルです。";

    private final File XmlTVDTD;

    /**
     * xmltv.dtdをファイルから読み込ませる。
     *
     * @author normal
     * @param XmlTVDTD
     * dtdファイル。ファイルが存在しないか設定されなかった場合、このクラスをセットされたDocumentBuilderはデフォルトの動作をする。
     */
    public XmlTvDTDResolver(File XmlTVDTD) {

        if ((XmlTVDTD != null)) {
            if ((XmlTVDTD.isFile())) {
                log.log(Level.FINE, MSG_SUCCESS, XmlTVDTD.getAbsolutePath());
                this.XmlTVDTD = XmlTVDTD;
            } else {
                log.log(Level.WARNING, "{0}は実在しないか、ファイルではありません。{0}は無視されます。", XmlTVDTD.getAbsolutePath());
                this.XmlTVDTD = null;
            }
        } else {
            log.log(Level.WARNING, "DTDファイルが指定されませんでした。");
            this.XmlTVDTD = null;
        }
    }

    /**
     * 公開識別子もしくはシステム識別子にxmltv.dtdを含んだ文字列があった場合、DocumentBuilderに対し、このクラスで指定されたファイルからxmltv.dtdを読み込ませる。
     * ファイルが指定されなかった場合はnullを返す。
     */
    @Override
    public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
        if (this.XmlTVDTD == null) {
            log.log(Level.FINE, "DTDファイルが指定されませんでした。");
            return null;
        } else {
            log.log(Level.FINE, MSG_SUCCESS, XmlTVDTD.getAbsolutePath());
        }

        if ((publicId != null && publicId.contains(DTD_NAME)) || (systemId != null && systemId.contains(DTD_NAME))) {
            log.log(Level.FINE, "識別子を確認しました。");
            InputSource source = new InputSource(new FileInputStream(this.XmlTVDTD));
            source.setPublicId(publicId);
            source.setSystemId(systemId);
            return source;
        } else {
            log.log(Level.FINE, "公開識別子、システム識別子とも、{0}を含む文字列ではありませんでした。", this.XmlTVDTD);
            return null;
        }
    }
}
